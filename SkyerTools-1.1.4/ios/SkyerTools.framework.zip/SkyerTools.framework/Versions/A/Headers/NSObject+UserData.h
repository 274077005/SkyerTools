//
//  NSObject+UserData.h
//  skyer工程集合
//
//  Created by SoKing on 2017/9/27.
//  Copyright © 2017年 skyer. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (UserData)
@property (nonatomic ,strong) id userData;
@end
